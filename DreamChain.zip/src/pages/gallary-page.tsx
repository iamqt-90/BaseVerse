import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const GallaryPage: FunctionComponent = () => {
  const navigate = useNavigate();

  const onHomeTextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onSamJamTextClick = useCallback(() => {
    navigate("/user-dashboard");
  }, [navigate]);

  const onViewTextClick = useCallback(() => {
    navigate("/nft-page-for-audio");
  }, [navigate]);

  return (
    <div className="w-full relative bg-gray-200 h-[1024px] overflow-hidden text-left text-sm text-white font-inter">
      <div className="absolute top-[0px] left-[0px] bg-gray-200 w-[1444.5px] h-[1024px]" />
      <div className="absolute top-[0px] left-[0px] shadow-[0px_2px_8px_rgba(0,_0,_0,_0.05),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] [background:radial-gradient(50%_50%_at_50%_50%,_#0e0037_42.31%,_#08001d)] w-[1444.5px] h-[78.6px]" />
      <img
        className="absolute top-[21.5px] left-[27.3px] w-[36.3px] h-[34.5px] overflow-hidden"
        alt=""
        src="/frame15.svg"
      />
      <div className="absolute top-[21.5px] left-[72.7px] text-xl leading-[30px] font-semibold inline-block w-[140.8px] h-[32.3px]">
        DreamScape
      </div>
      <div
        className="absolute top-[25.8px] left-[247.6px] text-base leading-[24px] font-medium inline-block w-[61.3px] h-[25.8px] cursor-pointer"
        onClick={onHomeTextClick}
      >
        Home
      </div>
      <img
        className="absolute top-[18px] left-[1304px] rounded-26843481xl w-[45.4px] h-[43.1px] object-cover"
        alt=""
        src="/image5@2x.png"
      />
      <div
        className="absolute top-[29px] left-[1342px] leading-[21px] font-medium text-right inline-block w-[78.4px] h-[22.6px] cursor-pointer"
        onClick={onSamJamTextClick}
      >
        Sam Jam
      </div>
      <div className="absolute top-[104.4px] left-[27.3px] shadow-[0px_4px_12px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-lavender-100 border-aliceblue border-solid border-[1px] box-border w-[340.7px] h-[106.6px]" />
      <div className="absolute top-[131.4px] left-[55.6px] shadow-[0px_2px_4px_rgba(0,_0,_0,_0.02),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-xl bg-white border-lavender-300 border-solid border-[1px] box-border w-[283.9px] h-[53.8px]" />
      <div className="absolute top-[236.9px] left-[27.3px] shadow-[0px_4px_12px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-lavender-100 border-aliceblue border-solid border-[1px] box-border w-[340.7px] h-[278.9px]" />
      <div className="absolute top-[262.7px] left-[55.6px] leading-[21px] font-semibold text-dimgray inline-block w-[123.8px] h-[22.6px]">
        FILTER BY TYPE
      </div>
      <div className="absolute top-[303.6px] left-[55.6px] rounded-xl bg-plum w-[283.9px] h-[53.8px]" />
      <div className="absolute top-[317.6px] left-[75px] text-base leading-[24px] text-mediumblue-100 inline-block w-[120.4px] h-[25.8px]">
        Audio Dreams
      </div>
      <div className="absolute top-[369.3px] left-[55.6px] rounded-xl bg-plum w-[283.9px] h-[53.8px]" />
      <div className="absolute top-[383.3px] left-[75px] text-base leading-[24px] text-mediumblue-100 inline-block w-[107.9px] h-[25.8px]">
        Text Dreams
      </div>
      <div className="absolute top-[436.1px] left-[55.6px] rounded-xl bg-plum w-[283.9px] h-[53.8px]" />
      <div className="absolute top-[450.1px] left-[75px] text-base leading-[24px] text-mediumblue-100 inline-block w-[130.6px] h-[25.8px]">
        Sketch Dreams
      </div>
      <div className="absolute top-[541.6px] left-[27.3px] shadow-[0px_4px_12px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-lavender-100 border-aliceblue border-solid border-[1px] box-border w-[340.7px] h-[146.4px]" />
      <div className="absolute top-[568.5px] left-[55.6px] leading-[21px] font-semibold text-dimgray inline-block w-[69.3px] h-[22.6px]">
        SORT BY
      </div>
      <div className="absolute top-[608.4px] left-[55.6px] rounded-xl bg-plum w-[283.9px] h-[53.8px]" />
      <img
        className="absolute top-[628.8px] left-[312.3px] w-[13.6px] h-[12.9px] overflow-hidden"
        alt=""
        src="/frame16.svg"
      />
      <div className="absolute top-[109.8px] left-[404.3px] text-5xl leading-[36px] font-semibold inline-block w-[187.4px] h-[38.8px]">
        Dream Gallery
      </div>
      <div className="absolute top-[104.4px] left-[1179.9px] shadow-[0px_4px_12px_rgba(67,_24,_209,_0.2),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-xl bg-mediumblue-200 w-[237.3px] h-[51.7px]" />
      <img
        className="absolute top-[119.5px] left-[1207.2px] w-[22.7px] h-[21.5px] overflow-hidden"
        alt=""
        src="/frame17.svg"
      />
      <div className="absolute top-[117.4px] left-[1239px] text-base leading-[24px] text-center inline-block w-[151px] h-[25.8px]">
        New Dream Entry
      </div>
      <div className="absolute top-[182px] left-[404.3px] shadow-[0px_4px_12px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-lavender-100 border-aliceblue border-solid border-[1px] box-border w-[325.9px] h-[269.2px]" />
      <div className="absolute top-[208.9px] left-[432.7px] rounded-26843481xl bg-aliceblue w-[45.4px] h-[43.1px]" />
      <img
        className="absolute top-[219.7px] left-[444px] w-[22.7px] h-[21.5px] overflow-hidden"
        alt=""
        src="/frame18.svg"
      />
      <div className="absolute top-[208.9px] left-[491.7px] text-base leading-[24px] font-semibold text-gray-100 inline-block w-[197.6px] h-[25.8px]">
        Flying Over Mountains
      </div>
      <div className="absolute top-[233.7px] left-[491.7px] leading-[21px] text-dimgray inline-block w-[90.9px] h-[22.6px]">
        2024-02-15
      </div>
      <div className="absolute top-[275.7px] left-[432.7px] text-mini leading-[22.5px] text-darkslategray inline-block w-[251px] h-[73.2px]">
        Soaring through misty peaks at dawn, feeling weightless and free
      </div>
      <div className="absolute top-[363.9px] left-[432.7px] border-aliceblue border-solid border-t-[0.8px] box-border w-[269.1px] h-[59.2px]" />
      <div className="absolute top-[382.3px] left-[432.7px] rounded-lg bg-midnightblue-300 w-[96.5px] h-[42px]" />
      <div
        className="absolute top-[390.9px] left-[462.2px] leading-[21px] font-medium text-center inline-block w-[38.6px] h-[22.6px] cursor-pointer"
        onClick={onViewTextClick}
      >
        View
      </div>
      <div className="absolute top-[382.3px] left-[538.3px] rounded-lg bg-white border-mediumblue-100 border-solid border-[1px] box-border w-[98.8px] h-[42px]" />
      <div className="absolute top-[390.9px] left-[573.5px] leading-[21px] font-medium text-mediumblue-100 text-center inline-block w-[29.5px] h-[22.6px]">
        Edit
      </div>
      <div className="absolute top-[382.3px] left-[645px] rounded-lg bg-white border-orangered border-solid border-[1px] box-border w-[56.8px] h-[42px]" />
      <img
        className="absolute top-[394.1px] left-[664.3px] w-[18.2px] h-[17.2px] overflow-hidden"
        alt=""
        src="/frame19.svg"
      />
      <div className="absolute top-[182px] left-[748.4px] shadow-[0px_4px_12px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-lavender-100 border-aliceblue border-solid border-[1px] box-border w-[325.9px] h-[269.2px]" />
      <div className="absolute top-[208.9px] left-[775.6px] rounded-26843481xl bg-lavenderblush w-[45.4px] h-[43.1px]" />
      <img
        className="absolute top-[219.7px] left-[787px] w-[22.7px] h-[21.5px] overflow-hidden"
        alt=""
        src="/frame20.svg"
      />
      <div className="absolute top-[208.9px] left-[834.7px] text-base leading-[24px] font-semibold text-gray-100 inline-block w-[124.9px] h-[25.8px]">
        Ocean Depths
      </div>
      <div className="absolute top-[233.7px] left-[834.7px] leading-[21px] text-dimgray inline-block w-[92px] h-[22.6px]">
        2024-02-14
      </div>
      <div className="absolute top-[275.7px] left-[775.6px] text-mini leading-[22.5px] text-darkslategray inline-block w-[232.8px] h-[73.2px]">
        Exploring luminescent caves beneath the sea, discovering ancient ruins
      </div>
      <div className="absolute top-[363.9px] left-[775.6px] border-aliceblue border-solid border-t-[0.8px] box-border w-[269.1px] h-[59.2px]" />
      <div className="absolute top-[382.3px] left-[775.6px] rounded-lg bg-midnightblue-300 w-[96.5px] h-[42px]" />
      <div className="absolute top-[390.9px] left-[806.3px] leading-[21px] font-medium text-center inline-block w-[38.6px] h-[22.6px]">
        View
      </div>
      <div className="absolute top-[382.3px] left-[881.3px] rounded-lg bg-white border-mediumblue-100 border-solid border-[1px] box-border w-[98.8px] h-[42px]" />
      <div className="absolute top-[390.9px] left-[916.5px] leading-[21px] font-medium text-mediumblue-100 text-center inline-block w-[29.5px] h-[22.6px]">
        Edit
      </div>
      <div className="absolute top-[382.3px] left-[989.1px] rounded-lg bg-white border-orangered border-solid border-[1px] box-border w-[56.8px] h-[42px]" />
      <img
        className="absolute top-[394.1px] left-[1008.4px] w-[18.2px] h-[17.2px] overflow-hidden"
        alt=""
        src="/frame21.svg"
      />
      <div className="absolute top-[182px] left-[1091.3px] shadow-[0px_4px_12px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-lavender-100 border-aliceblue border-solid border-[1px] box-border w-[325.9px] h-[269.2px]" />
      <div className="absolute top-[208.9px] left-[1119.7px] rounded-26843481xl bg-honeydew w-[45.4px] h-[43.1px]" />
      <img
        className="absolute top-[219.7px] left-[1131.1px] w-[22.7px] h-[21.5px] overflow-hidden"
        alt=""
        src="/frame22.svg"
      />
      <div className="absolute top-[208.9px] left-[1178.8px] text-base leading-[24px] font-semibold text-gray-100 inline-block w-[132.9px] h-[25.8px]">
        Crystal Garden
      </div>
      <div className="absolute top-[233.7px] left-[1178.8px] leading-[21px] text-dimgray inline-block w-[90.9px] h-[22.6px]">
        2024-02-13
      </div>
      <div className="absolute top-[275.7px] left-[1119.7px] text-mini leading-[22.5px] text-darkslategray inline-block w-[261.2px] h-[73.2px]">
        Walking through a garden where flowers were made of pure crystal
      </div>
      <div className="absolute top-[363.9px] left-[1119.7px] border-aliceblue border-solid border-t-[0.8px] box-border w-[269.1px] h-[59.2px]" />
      <div className="absolute top-[382.3px] left-[1119.7px] rounded-lg bg-midnightblue-300 w-[96.5px] h-[42px]" />
      <div className="absolute top-[390.9px] left-[1149.3px] leading-[21px] font-medium text-center inline-block w-[38.6px] h-[22.6px]">
        View
      </div>
      <div className="absolute top-[382.3px] left-[1225.4px] rounded-lg bg-white border-mediumblue-100 border-solid border-[1px] box-border w-[98.8px] h-[42px]" />
      <div className="absolute top-[390.9px] left-[1260.6px] leading-[21px] font-medium text-mediumblue-100 text-center inline-block w-[29.5px] h-[22.6px]">
        Edit
      </div>
      <div className="absolute top-[382.3px] left-[1333.2px] rounded-lg bg-white border-orangered border-solid border-[1px] box-border w-[56.8px] h-[42px]" />
      <img
        className="absolute top-[394.1px] left-[1351.4px] w-[18.2px] h-[17.2px] overflow-hidden"
        alt=""
        src="/frame23.svg"
      />
      <div className="absolute top-[467.3px] left-[404.3px] shadow-[0px_4px_12px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-lavender-100 border-aliceblue border-solid border-[1px] box-border w-[325.9px] h-[269.2px]" />
      <div className="absolute top-[494.2px] left-[432.7px] rounded-26843481xl bg-lavenderblush w-[45.4px] h-[43.1px]" />
      <img
        className="absolute top-[505px] left-[444px] w-[22.7px] h-[21.5px] overflow-hidden"
        alt=""
        src="/frame24.svg"
      />
      <div className="absolute top-[494.2px] left-[491.7px] text-base leading-[24px] font-semibold text-gray-100 inline-block w-[102.2px] h-[25.8px]">
        Time Travel
      </div>
      <div className="absolute top-[520.1px] left-[491.7px] leading-[21px] text-dimgray inline-block w-[90.9px] h-[22.6px]">
        2024-02-12
      </div>
      <div className="absolute top-[562.1px] left-[432.7px] text-mini leading-[22.5px] text-darkslategray inline-block w-[247.6px] h-[73.2px]">
        Found myself in ancient Egypt, watching the pyramids being built
      </div>
      <div className="absolute top-[650.4px] left-[432.7px] border-aliceblue border-solid border-t-[0.8px] box-border w-[269.1px] h-[59.2px]" />
      <div className="absolute top-[667.6px] left-[432.7px] rounded-lg bg-midnightblue-300 w-[96.5px] h-[42px]" />
      <div className="absolute top-[677.3px] left-[462.2px] leading-[21px] font-medium text-center inline-block w-[38.6px] h-[22.6px]">
        View
      </div>
      <div className="absolute top-[667.6px] left-[538.3px] rounded-lg bg-white border-mediumblue-100 border-solid border-[1px] box-border w-[98.8px] h-[42px]" />
      <div className="absolute top-[677.3px] left-[573.5px] leading-[21px] font-medium text-mediumblue-100 text-center inline-block w-[29.5px] h-[22.6px]">
        Edit
      </div>
      <div className="absolute top-[667.6px] left-[645px] rounded-lg bg-white border-orangered border-solid border-[1px] box-border w-[56.8px] h-[42px]" />
      <img
        className="absolute top-[680.5px] left-[664.3px] w-[18.2px] h-[17.2px] overflow-hidden"
        alt=""
        src="/frame25.svg"
      />
      <div className="absolute top-[467.3px] left-[748.4px] shadow-[0px_4px_12px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-lavender-100 border-aliceblue border-solid border-[1px] box-border w-[325.9px] h-[244.4px]" />
      <div className="absolute top-[494.2px] left-[775.6px] rounded-26843481xl bg-aliceblue w-[45.4px] h-[43.1px]" />
      <img
        className="absolute top-[505px] left-[787px] w-[22.7px] h-[21.5px] overflow-hidden"
        alt=""
        src="/frame26.svg"
      />
      <div className="absolute top-[494.2px] left-[834.7px] text-base leading-[24px] font-semibold text-gray-100 inline-block w-[149.9px] h-[25.8px]">
        Starship Journey
      </div>
      <div className="absolute top-[520.1px] left-[834.7px] leading-[21px] text-dimgray inline-block w-[88.6px] h-[22.6px]">
        2024-02-11
      </div>
      <div className="absolute top-[562.1px] left-[775.6px] text-mini leading-[22.5px] text-darkslategray inline-block w-[211.2px] h-[48.5px]">
        Piloting a vessel through a nebula of swirling colors
      </div>
      <div className="absolute top-[625.6px] left-[775.6px] border-aliceblue border-solid border-t-[0.8px] box-border w-[269.1px] h-[59.2px]" />
      <div className="absolute top-[643.9px] left-[775.6px] rounded-lg bg-midnightblue-300 w-[96.5px] h-[42px]" />
      <div className="absolute top-[652.5px] left-[806.3px] leading-[21px] font-medium text-center inline-block w-[38.6px] h-[22.6px]">
        View
      </div>
      <div className="absolute top-[643.9px] left-[881.3px] rounded-lg bg-white border-mediumblue-100 border-solid border-[1px] box-border w-[98.8px] h-[42px]" />
      <div className="absolute top-[652.5px] left-[916.5px] leading-[21px] font-medium text-mediumblue-100 text-center inline-block w-[29.5px] h-[22.6px]">
        Edit
      </div>
      <div className="absolute top-[643.9px] left-[989.1px] rounded-lg bg-white border-orangered border-solid border-[1px] box-border w-[56.8px] h-[42px]" />
      <img
        className="absolute top-[655.7px] left-[1008.4px] w-[18.2px] h-[17.2px] overflow-hidden"
        alt=""
        src="/frame27.svg"
      />
      <div className="absolute top-[467.3px] left-[1091.3px] shadow-[0px_4px_12px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-lavender-100 border-aliceblue border-solid border-[1px] box-border w-[325.9px] h-[244.4px]" />
      <div className="absolute top-[494.2px] left-[1119.7px] rounded-26843481xl bg-honeydew w-[45.4px] h-[43.1px]" />
      <img
        className="absolute top-[505px] left-[1131.1px] w-[22.7px] h-[21.5px] overflow-hidden"
        alt=""
        src="/frame28.svg"
      />
      <div className="absolute top-[494.2px] left-[1178.8px] text-base leading-[24px] font-semibold text-gray-100 inline-block w-[165.8px] h-[25.8px]">
        Forest of Whispers
      </div>
      <div className="absolute top-[520.1px] left-[1178.8px] leading-[21px] text-dimgray inline-block w-[90.9px] h-[22.6px]">
        2024-02-10
      </div>
      <div className="absolute top-[562.1px] left-[1119.7px] text-mini leading-[22.5px] text-darkslategray inline-block w-[204.4px] h-[73.2px]">
        Trees that communicated through glowing symbols
      </div>
      <div className="absolute top-[625.6px] left-[1119.7px] border-aliceblue border-solid border-t-[0.8px] box-border w-[269.1px] h-[59.2px]" />
      <div className="absolute top-[643.9px] left-[1119.7px] rounded-lg bg-midnightblue-300 w-[96.5px] h-[42px]" />
      <div className="absolute top-[652.5px] left-[1149.3px] leading-[21px] font-medium text-center inline-block w-[38.6px] h-[22.6px]">
        View
      </div>
      <div className="absolute top-[643.9px] left-[1225.4px] rounded-lg bg-white border-mediumblue-100 border-solid border-[1px] box-border w-[98.8px] h-[42px]" />
      <div className="absolute top-[652.5px] left-[1260.6px] leading-[21px] font-medium text-mediumblue-100 text-center inline-block w-[29.5px] h-[22.6px]">
        Edit
      </div>
      <div className="absolute top-[643.9px] left-[1333.2px] rounded-lg bg-white border-orangered border-solid border-[1px] box-border w-[56.8px] h-[42px]" />
      <img
        className="absolute top-[655.7px] left-[1351.4px] w-[18.2px] h-[17.2px] overflow-hidden"
        alt=""
        src="/frame29.svg"
      />
      <div className="absolute top-[753.7px] left-[404.3px] shadow-[0px_4px_12px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-lavender-100 border-aliceblue border-solid border-[1px] box-border w-[325.9px] h-[244.4px]" />
      <div className="absolute top-[780.7px] left-[432.7px] rounded-26843481xl bg-lavenderblush w-[45.4px] h-[43.1px]" />
      <img
        className="absolute top-[791.4px] left-[444px] w-[22.7px] h-[21.5px] overflow-hidden"
        alt=""
        src="/frame30.svg"
      />
      <div className="absolute top-[780.7px] left-[491.7px] text-base leading-[24px] font-semibold text-gray-100 inline-block w-[113.6px] h-[25.8px]">
        Desert Oasis
      </div>
      <div className="absolute top-[805.4px] left-[491.7px] leading-[21px] text-dimgray inline-block w-[94.3px] h-[22.6px]">
        2024-02-09
      </div>
      <div className="absolute top-[847.4px] left-[432.7px] text-mini leading-[22.5px] text-darkslategray inline-block w-[251px] h-[48.5px]">
        Found a magical pool of water surrounded by floating crystals
      </div>
      <div className="absolute top-[912px] left-[432.7px] border-aliceblue border-solid border-t-[0.8px] box-border w-[269.1px] h-[59.2px]" />
      <div className="absolute top-[929.2px] left-[432.7px] rounded-lg bg-midnightblue-300 w-[96.5px] h-[42px]" />
      <div className="absolute top-[938.9px] left-[462.2px] leading-[21px] font-medium text-center inline-block w-[38.6px] h-[22.6px]">
        View
      </div>
      <div className="absolute top-[929.2px] left-[538.3px] rounded-lg bg-white border-mediumblue-100 border-solid border-[1px] box-border w-[98.8px] h-[42px]" />
      <div className="absolute top-[938.9px] left-[573.5px] leading-[21px] font-medium text-mediumblue-100 text-center inline-block w-[29.5px] h-[22.6px]">
        Edit
      </div>
      <div className="absolute top-[929.2px] left-[645px] rounded-lg bg-white border-orangered border-solid border-[1px] box-border w-[56.8px] h-[42px]" />
      <img
        className="absolute top-[942.2px] left-[664.3px] w-[18.2px] h-[17.2px] overflow-hidden"
        alt=""
        src="/frame31.svg"
      />
      <div className="absolute top-[753.7px] left-[748.4px] shadow-[0px_4px_12px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-lavender-100 border-aliceblue border-solid border-[1px] box-border w-[325.9px] h-[244.4px]" />
      <div className="absolute top-[780.7px] left-[775.6px] rounded-26843481xl bg-honeydew w-[45.4px] h-[43.1px]" />
      <img
        className="absolute top-[791.4px] left-[787px] w-[22.7px] h-[21.5px] overflow-hidden"
        alt=""
        src="/frame32.svg"
      />
      <div className="absolute top-[780.7px] left-[834.7px] text-base leading-[24px] font-semibold text-gray-100 inline-block w-[92px] h-[25.8px]">
        Cloud City
      </div>
      <div className="absolute top-[805.4px] left-[834.7px] leading-[21px] text-dimgray inline-block w-[93.1px] h-[22.6px]">
        2024-02-08
      </div>
      <div className="absolute top-[847.4px] left-[775.6px] text-mini leading-[22.5px] text-darkslategray inline-block w-[244.2px] h-[48.5px]">
        Walking through a city built on clouds with rainbow bridges
      </div>
      <div className="absolute top-[912px] left-[775.6px] border-aliceblue border-solid border-t-[0.8px] box-border w-[269.1px] h-[59.2px]" />
      <div className="absolute top-[929.2px] left-[775.6px] rounded-lg bg-midnightblue-300 w-[96.5px] h-[42px]" />
      <div className="absolute top-[938.9px] left-[806.3px] leading-[21px] font-medium text-center inline-block w-[38.6px] h-[22.6px]">
        View
      </div>
      <div className="absolute top-[929.2px] left-[881.3px] rounded-lg bg-white border-mediumblue-100 border-solid border-[1px] box-border w-[98.8px] h-[42px]" />
      <div className="absolute top-[938.9px] left-[916.5px] leading-[21px] font-medium text-mediumblue-100 text-center inline-block w-[29.5px] h-[22.6px]">
        Edit
      </div>
      <div className="absolute top-[929.2px] left-[989.1px] rounded-lg bg-white border-orangered border-solid border-[1px] box-border w-[56.8px] h-[42px]" />
      <img
        className="absolute top-[942.2px] left-[1008.4px] w-[18.2px] h-[17.2px] overflow-hidden"
        alt=""
        src="/frame33.svg"
      />
      <div className="absolute top-[753.7px] left-[1091.3px] shadow-[0px_4px_12px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-lavender-100 border-aliceblue border-solid border-[1px] box-border w-[325.9px] h-[244.4px]" />
      <div className="absolute top-[780.7px] left-[1119.7px] rounded-26843481xl bg-aliceblue w-[45.4px] h-[43.1px]" />
      <img
        className="absolute top-[791.4px] left-[1131.1px] w-[22.7px] h-[21.5px] overflow-hidden"
        alt=""
        src="/frame34.svg"
      />
      <div className="absolute top-[780.7px] left-[1178.8px] text-base leading-[24px] font-semibold text-gray-100 inline-block w-[180.6px] h-[25.8px]">
        Underwater Concert
      </div>
      <div className="absolute top-[805.4px] left-[1178.8px] leading-[21px] text-dimgray inline-block w-[93.1px] h-[22.6px]">
        2024-02-07
      </div>
      <div className="absolute top-[847.4px] left-[1119.7px] text-mini leading-[22.5px] text-darkslategray inline-block w-[243px] h-[48.5px]">
        Listening to whale songs in an underwater amphitheater
      </div>
      <div className="absolute top-[912px] left-[1119.7px] border-aliceblue border-solid border-t-[0.8px] box-border w-[269.1px] h-[59.2px]" />
      <div className="absolute top-[929.2px] left-[1119.7px] rounded-lg bg-midnightblue-300 w-[96.5px] h-[42px]" />
      <div className="absolute top-[938.9px] left-[1149.3px] leading-[21px] font-medium text-center inline-block w-[38.6px] h-[22.6px]">
        View
      </div>
      <div className="absolute top-[929.2px] left-[1225.4px] rounded-lg bg-white border-mediumblue-100 border-solid border-[1px] box-border w-[98.8px] h-[42px]" />
      <div className="absolute top-[938.9px] left-[1260.6px] leading-[21px] font-medium text-mediumblue-100 text-center inline-block w-[29.5px] h-[22.6px]">
        Edit
      </div>
      <div className="absolute top-[929.2px] left-[1333.2px] rounded-lg bg-white border-orangered border-solid border-[1px] box-border w-[56.8px] h-[42px]" />
      <img
        className="absolute top-[942.2px] left-[1351.4px] w-[18.2px] h-[17.2px] overflow-hidden"
        alt=""
        src="/frame35.svg"
      />
      <div className="absolute top-[144.3px] left-[73.8px] text-base text-darkgray flex items-center w-[144.2px] h-[20.5px]">
        Search dreams...
      </div>
      <div className="absolute top-[621.3px] left-[73.8px] text-base text-black flex items-center w-[109px] h-[20.5px]">
        Newest First
      </div>
      <div
        className="absolute top-[25px] left-[343px] text-base leading-[24px] font-medium inline-block w-[61.3px] h-[25.8px] cursor-pointer"
        onClick={onSamJamTextClick}
      >
        Profile
      </div>
    </div>
  );
};

export default GallaryPage;

import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const UserDashboard: FunctionComponent = () => {
  const navigate = useNavigate();

  const onStartDreamingTextClick = useCallback(() => {
    navigate("/dreaming-page");
  }, [navigate]);

  const onViewTextClick = useCallback(() => {
    navigate("/nft-page-for-audio");
  }, [navigate]);

  const onHomeTextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onGalleryTextClick = useCallback(() => {
    navigate("/gallary-page");
  }, [navigate]);

  return (
    <div className="w-full relative bg-white h-[1024px] overflow-hidden text-left text-base-8 text-dimgray font-inter">
      <img
        className="absolute top-[22px] left-[24px] w-[35.9px] h-[34px] overflow-hidden"
        alt=""
        src="/frame4.svg"
      />
      <img
        className="absolute top-[592px] left-[128px] w-6 h-6 overflow-hidden"
        alt=""
        src="/frame5.svg"
      />
      <img
        className="absolute top-[742px] left-[301px] w-[18px] h-[18px] overflow-hidden"
        alt=""
        src="/frame6.svg"
      />
      <img
        className="absolute top-[592px] left-[498px] w-6 h-6 overflow-hidden"
        alt=""
        src="/frame7.svg"
      />
      <img
        className="absolute top-[742px] left-[671px] w-[18px] h-[18px] overflow-hidden"
        alt=""
        src="/frame6.svg"
      />
      <img
        className="absolute top-[592px] left-[868px] w-6 h-6 overflow-hidden"
        alt=""
        src="/frame8.svg"
      />
      <div className="absolute top-[0px] left-[0px] bg-gray-200 w-[1440px] h-[1024px]" />
      <div className="absolute top-[125.7px] left-[67.9px] shadow-[0px_4.5px_13.6px_rgba(0,_0,_0,_0.25),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-lg-1 bg-plum border-aliceblue border-solid border-[1.1px] box-border w-[1304.2px] h-[816.2px]" />
      <img
        className="absolute top-[167.5px] left-[105.3px] rounded-30388847xl w-[135.8px] h-[135.8px] object-cover"
        alt=""
        src="/image1@2x.png"
      />
      <div className="absolute top-[161.9px] left-[268.3px] text-[27.2px] leading-[40.8px] font-semibold text-gray-100">
        Sam Jam
      </div>
      <div className="absolute top-[211.7px] left-[268.3px] text-mid leading-[25.5px] text-darkslategray">
        Explorer of dreams and collector of magical moments. Join me on this
        journey through the dreamscape.
      </div>
      <div className="absolute top-[255.8px] left-[268.3px] shadow-[0px_4.5px_13.6px_rgba(67,_24,_209,_0.2),_2px_0px_0px_rgba(0,_0,_0,_0.24),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-sm-6 bg-midnightblue-300 border-black border-solid border-[1px] box-border w-[167.5px] h-[50.9px]" />
      <div
        className="absolute top-[267.4px] left-[294.5px] leading-[23.8px] font-medium text-white text-center cursor-pointer"
        onClick={onStartDreamingTextClick}
      >
        Start Dreaming
      </div>
      <div className="absolute top-[343px] left-[105.3px] shadow-[0px_0px_0px_rgba(0,_0,_0,_0.25)] rounded-sm-6 bg-lavender-100 w-[391.7px] h-[143.8px]" />
      <div className="absolute top-[371.3px] left-[133.6px] text-17xl-2 leading-[54.3px] font-semibold text-gray-100">
        42
      </div>
      <div className="absolute top-[434.7px] left-[133.6px] leading-[23.8px]">
        Dreams Created
      </div>
      <div className="absolute top-[343px] left-[524.2px] rounded-sm-6 bg-lavender-100 border-aliceblue border-solid border-[1.1px] box-border w-[391.7px] h-[143.8px]" />
      <div className="absolute top-[371.3px] left-[552.5px] text-17xl-2 leading-[54.3px] font-semibold text-gray-100">
        156
      </div>
      <div className="absolute top-[434.7px] left-[552.5px] leading-[23.8px]">
        Dreams Bookmarked
      </div>
      <div className="absolute top-[343px] left-[943px] rounded-sm-6 bg-lavender-100 border-aliceblue border-solid border-[1.1px] box-border w-[391.7px] h-[143.8px]" />
      <div className="absolute top-[371.3px] left-[971.3px] text-17xl-2 leading-[54.3px] font-semibold text-gray-100">
        890
      </div>
      <div className="absolute top-[434.7px] left-[971.3px] leading-[23.8px]">
        Dream Tokens
      </div>
      <div className="absolute top-[541.1px] left-[105.3px] border-mediumblue-100 border-solid border-b-[1.8px] box-border w-[139.2px] h-[53.2px]" />
      <div className="absolute top-[553.6px] left-[132.5px] leading-[23.8px] font-medium text-mediumblue-100 text-center">
        My Dreams
      </div>
      <div className="absolute top-[554.7px] left-[289.8px] leading-[23.8px] font-medium text-center">
        Bookmarked
      </div>
      <div className="absolute top-[554.7px] left-[457.4px] leading-[23.8px] font-medium text-center">
        Drafts
      </div>
      <div className="absolute top-[630.6px] left-[105.3px] shadow-[0px_4.5px_13.6px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-lg-1 bg-white border-aliceblue border-solid border-[1.1px] box-border w-[391.7px] h-[275.1px]" />
      <div className="absolute top-[658.9px] left-[133.6px] rounded-30388847xl bg-aliceblue w-[50.9px] h-[48.7px]" />
      <div className="absolute top-[657.7px] left-[202.6px] text-lg-1 leading-[27.2px] font-semibold text-gray-100">
        Flying Over Mountains
      </div>
      <div className="absolute top-[684.9px] left-[202.6px] leading-[23.8px]">
        2024-02-15
      </div>
      <div className="absolute top-[729.1px] left-[133.6px] text-mid leading-[25.5px] text-darkslategray inline-block w-[303.4px]">
        Soaring through misty peaks at dawn, feeling weightless and free
      </div>
      <div className="absolute top-[804.9px] left-[133.6px] border-aliceblue border-solid border-t-[0.9px] box-border w-[336.2px] h-[71.3px]" />
      <div className="absolute top-[825.3px] left-[133.6px] rounded-3xs-1 bg-midnightblue-300 w-[90.6px] h-[50.9px]" />
      <div
        className="absolute top-[837.7px] left-[160.8px] leading-[23.8px] font-medium text-white text-center cursor-pointer"
        onClick={onViewTextClick}
      >
        View
      </div>
      <div className="absolute top-[824.2px] left-[233.2px] rounded-3xs-1 border-mediumblue-100 border-solid border-[1.1px] box-border w-[84.9px] h-[53.2px]" />
      <div className="absolute top-[837.7px] left-[261.5px] leading-[23.8px] font-medium text-mediumblue-100 text-center">
        Edit
      </div>
      <div className="absolute top-[630.6px] left-[524.2px] shadow-[0px_4.5px_13.6px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-lg-1 bg-white border-aliceblue border-solid border-[1.1px] box-border w-[391.7px] h-[275.1px]" />
      <div className="absolute top-[826px] left-[746px] w-[47.5px] h-[47.5px]">
        <div className="absolute top-[0px] left-[0px] w-[47.5px] h-[47.5px]">
          <div className="absolute top-[0px] left-[0px] rounded-3xs-1 border-orangered border-solid border-[1.1px] box-border w-[47.5px] h-[47.5px]" />
        </div>
        <img
          className="absolute top-[11.6px] left-[11.8px] w-6 h-6"
          alt=""
          src="/bookmark.svg"
        />
      </div>
      <div className="absolute top-[658.9px] left-[552.5px] rounded-30388847xl bg-lavenderblush w-[50.9px] h-[48.7px]" />
      <div className="absolute top-[657.7px] left-[621.5px] text-lg-1 leading-[27.2px] font-semibold text-gray-100">
        Crystal Garden
      </div>
      <div className="absolute top-[684.9px] left-[621.5px] leading-[23.8px]">
        2024-02-13
      </div>
      <div className="absolute top-[729.1px] left-[552.5px] text-mid leading-[25.5px] text-darkslategray inline-block w-[324.9px]">
        Walking through a garden where flowers were made of pure crystal
      </div>
      <div className="absolute top-[804.9px] left-[552.5px] border-aliceblue border-solid border-t-[0.9px] box-border w-[336.2px] h-[71.3px]" />
      <div className="absolute top-[825.3px] left-[552.5px] rounded-3xs-1 bg-midnightblue-300 w-[90.6px] h-[50.9px]" />
      <div className="absolute top-[837.7px] left-[579.6px] leading-[23.8px] font-medium text-white text-center">
        View
      </div>
      <div className="absolute top-[824.2px] left-[652.1px] rounded-3xs-1 border-mediumblue-100 border-solid border-[1.1px] box-border w-[84.9px] h-[53.2px]" />
      <div className="absolute top-[837.7px] left-[680.4px] leading-[23.8px] font-medium text-mediumblue-100 text-center">
        Edit
      </div>
      <div className="absolute top-[630.6px] left-[943px] shadow-[0px_4.5px_13.6px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-lg-1 bg-white border-aliceblue border-solid border-[1.1px] box-border w-[391.7px] h-[275.1px]" />
      <div className="absolute top-[658.9px] left-[971.3px] rounded-30388847xl bg-honeydew w-[50.9px] h-[48.7px]" />
      <div className="absolute top-[657.7px] left-[1040.4px] text-lg-1 leading-[27.2px] font-semibold text-gray-100">
        Ocean Depths
      </div>
      <div className="absolute top-[684.9px] left-[1040.4px] leading-[23.8px]">
        2024-02-14
      </div>
      <div className="absolute top-[729.1px] left-[971.3px] text-mid leading-[25.5px] text-darkslategray inline-block w-[329.4px]">
        Exploring luminescent caves beneath the sea, discovering ancient ruins
      </div>
      <div className="absolute top-[804.9px] left-[971.3px] border-aliceblue border-solid border-t-[0.9px] box-border w-[336.2px] h-[71.3px]" />
      <div className="absolute top-[825.3px] left-[971.3px] rounded-3xs-1 bg-midnightblue-300 w-[90.6px] h-[50.9px]" />
      <div className="absolute top-[837.7px] left-[998.5px] leading-[23.8px] font-medium text-white text-center">
        View
      </div>
      <div className="absolute top-[824.2px] left-[1070.9px] rounded-3xs-1 border-mediumblue-100 border-solid border-[1.1px] box-border w-[84.9px] h-[53.2px]" />
      <div className="absolute top-[837.7px] left-[1099.2px] leading-[23.8px] font-medium text-mediumblue-100 text-center">
        Edit
      </div>
      <div className="absolute top-[0px] left-[0px] shadow-[0px_2px_8px_rgba(0,_0,_0,_0.05),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] [background:radial-gradient(50%_50%_at_50%_50%,_#0e0037_42.31%,_#08001d)] w-[1440px] h-[102px]" />
      <b className="absolute top-[24px] left-[27px] text-17xl leading-[48px] inline-block font-archivo text-white w-[225px] h-11 [text-shadow:1px_0_0_rgba(0,_0,_0,_0),_0_1px_0_rgba(0,_0,_0,_0),_-1px_0_0_rgba(0,_0,_0,_0),_0_-1px_0_rgba(0,_0,_0,_0)]">
        DreamScape
      </b>
      <b
        className="absolute top-[41px] left-[323px] text-lg leading-[24px] inline-block text-white w-[52.1px] h-[21.7px] cursor-pointer"
        onClick={onHomeTextClick}
      >
        Home
      </b>
      <div
        className="absolute top-[40.3px] left-[436.4px] text-lg leading-[24px] text-white inline-block w-[60px] h-[21.7px] cursor-pointer"
        onClick={onGalleryTextClick}
      >
        Gallery
      </div>
      <div className="absolute top-[826.4px] left-[327.2px] w-[47.5px] h-[47.5px]">
        <div className="absolute top-[0px] left-[0px] rounded-3xs-1 border-orangered border-solid border-[1.1px] box-border w-[47.5px] h-[47.5px]" />
      </div>
      <img
        className="absolute top-[838px] left-[339px] w-6 h-6"
        alt=""
        src="/bookmark1.svg"
      />
      <div className="absolute top-[827px] left-[1165px] w-[47.5px] h-[47.5px]">
        <div className="absolute top-[0px] left-[0px] w-[47.5px] h-[47.5px]">
          <div className="absolute top-[0px] left-[0px] rounded-3xs-1 border-orangered border-solid border-[1.1px] box-border w-[47.5px] h-[47.5px]" />
        </div>
        <img
          className="absolute top-[11.6px] left-[11.8px] w-6 h-6"
          alt=""
          src="/bookmark.svg"
        />
      </div>
    </div>
  );
};

export default UserDashboard;

import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const DreamingPage: FunctionComponent = () => {
  const navigate = useNavigate();

  const onVectorIconClick = useCallback(() => {
    navigate("/user-dashboard");
  }, [navigate]);

  const onHomeTextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className="w-full relative h-[1024px] text-center text-base text-white font-inter">
      <div className="absolute top-[0px] left-[0px] bg-gray-200 w-[1440px] h-[1024px]" />
      <div className="absolute top-[0px] left-[0px] shadow-[0px_2px_8px_rgba(0,_0,_0,_0.05),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] [background:radial-gradient(50%_50%_at_50%_50%,_#0e0037_42.31%,_#08001d)] w-[1440px] h-[112.5px]" />
      <div className="absolute top-[28.1px] left-[36.2px] w-[54.3px] h-[56.2px]">
        <div className="absolute top-[0px] left-[0px] shadow-[0px_2px_8px_rgba(67,_24,_209,_0.1),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-xl bg-gray-300 w-[54.3px] h-[56.2px]" />
      </div>
      <img
        className="absolute h-[1.6%] w-[1.42%] top-[4.69%] right-[94.89%] bottom-[93.71%] left-[3.69%] max-w-full overflow-hidden max-h-full cursor-pointer"
        alt=""
        src="/vector.svg"
        onClick={onVectorIconClick}
      />
      <div className="absolute top-[35.1px] left-[117.7px] text-5xl leading-[36px] font-semibold text-left inline-block w-[191.3px] h-[42.2px]">
        DreamScape
      </div>
      <div className="absolute top-[28.1px] left-[1298.5px] shadow-[0px_8px_32px_rgba(0,_0,_0,_0.58),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl [background:linear-gradient(90deg,_#2a00bd,_#00004a)] w-[105.3px] h-[56.2px]" />
      <div
        className="absolute top-[42.2px] left-[1325.7px] leading-[24px] inline-block w-[50.9px] h-[28.1px] cursor-pointer"
        onClick={onHomeTextClick}
      >
        Home
      </div>
      <div className="absolute top-[150px] left-[36.2px] shadow-[0px_8px_32px_rgba(0,_0,_0,_0.05),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-3xl bg-plum w-[878.5px] h-[834.2px]" />
      <div className="absolute top-[187.5px] left-[72.5px] shadow-[0px_2px_8px_rgba(0,_0,_0,_0.05)] rounded-xl bg-midnightblue-300 w-[122.3px] h-[56.2px]" />
      <img
        className="absolute h-[1.62%] w-[1.12%] top-[20.2%] right-[91.7%] bottom-[78.18%] left-[7.18%] max-w-full overflow-hidden max-h-full"
        alt=""
        src="/vector1.svg"
      />
      <div className="absolute top-[201.5px] left-[131.3px] leading-[24px] inline-block w-[37.4px] h-[28.1px]">
        Text
      </div>
      <div className="absolute top-[187.5px] left-[212.8px] shadow-[0px_2px_8px_rgba(0,_0,_0,_0.05)] rounded-xl bg-white w-[135.8px] h-[56.2px]" />
      <img
        className="absolute top-[203.9px] left-[240px] w-[22.6px] h-[23.4px] overflow-hidden"
        alt=""
        src="/frame9.svg"
      />
      <div className="absolute top-[201.5px] left-[271.7px] leading-[24px] text-gray-100 inline-block w-[49.8px] h-[28.1px]">
        Audio
      </div>
      <div className="absolute top-[187.5px] left-[366.8px] shadow-[0px_2px_8px_rgba(0,_0,_0,_0.05)] rounded-xl bg-white w-[144.9px] h-[56.2px]" />
      <img
        className="absolute top-[203.9px] left-[394px] w-[22.6px] h-[23.4px] overflow-hidden"
        alt=""
        src="/frame10.svg"
      />
      <div className="absolute top-[201.5px] left-[425.7px] leading-[24px] text-gray-100 inline-block w-[58.9px] h-[28.1px]">
        Sketch
      </div>
      <div className="absolute top-[271.8px] left-[72.5px] rounded-2xl bg-lavender-100 w-[806px] h-[592.8px]" />
      <div className="absolute top-[892.8px] left-[72.5px] shadow-[0px_8px_32px_rgba(67,_24,_209,_0.2),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl [background:linear-gradient(90deg,_#2a00bd,_#00004a)] w-[114.3px] h-[53.9px]" />
      <div className="absolute top-[905.7px] left-[108.7px] leading-[24px] inline-block w-[41.9px] h-[28.1px]">
        Save
      </div>
      <div className="absolute top-[892.8px] left-[204.9px] shadow-[0px_8px_32px_rgba(67,_24,_209,_0.2),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl [background:linear-gradient(90deg,_#2a00bd,_#00004a)] w-[150.6px] h-[53.9px]" />
      <div className="absolute top-[905.7px] left-[241.1px] leading-[24px] inline-block w-[79.2px] h-[28.1px]">
        Mint NFT
      </div>
      <div className="absolute top-[150px] left-[950.9px] shadow-[0px_8px_32px_rgba(0,_0,_0,_0.05),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-3xl bg-plum w-[452.8px] h-[834.2px]" />
      <div className="absolute top-[186.3px] left-[987.2px] text-xl leading-[30px] font-semibold text-gray-100 text-left inline-block w-[105.3px] h-[35.1px]">
        Summary
      </div>
      <div className="absolute top-[241.4px] left-[987.2px] rounded-2xl bg-lavender-100 w-[380.4px] h-[468.6px]" />
      <div className="absolute top-[461.6px] left-[1039.2px] leading-[24px] text-dimgray text-left inline-block w-[277.4px] h-[28.1px]">
        Save your entry to see summary
      </div>
    </div>
  );
};

export default DreamingPage;

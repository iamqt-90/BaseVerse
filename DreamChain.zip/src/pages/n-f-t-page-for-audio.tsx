import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const NFTPageForAudio: FunctionComponent = () => {
  const navigate = useNavigate();

  const onBackToGalleryClick = useCallback(() => {
    navigate("/gallary-page");
  }, [navigate]);

  return (
    <div className="w-full relative bg-gray-200 h-[1024px] overflow-hidden text-left text-sm text-dimgray font-inter">
      <div className="absolute top-[46.9px] left-[69px] rounded-lg bg-mediumblue-200 border-mediumblue-100 border-solid border-[1px] box-border w-[180.9px] h-[49.7px]" />
      <img
        className="absolute h-[0.93%] w-[0.32%] top-[6.54%] right-[93.06%] bottom-[92.53%] left-[6.62%] max-w-full overflow-hidden max-h-full"
        alt=""
        src="/vector3.svg"
      />
      <div
        className="absolute top-[60.8px] left-[107.9px] leading-[21px] font-medium text-white text-center inline-block w-[116.8px] h-[24.8px] cursor-pointer"
        onClick={onBackToGalleryClick}
      >
        Back to Gallery
      </div>
      <div className="absolute top-[57.6px] left-[268.2px] bg-lavender-300 w-[1.1px] h-[28.4px]" />
      <div className="absolute top-[58.8px] left-[287.7px] leading-[21px] text-lightgray inline-block w-[217.5px] h-[24.8px]">
        Thursday, February 15, 2024
      </div>
      <div className="absolute top-[46.9px] left-[1073.1px] shadow-[0px_8px_32px_rgba(67,_24,_209,_0.2),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-mediumblue-200 w-[154.6px] h-[49.7px]" />
      <div className="absolute top-[58.8px] left-[1100.6px] leading-[21px] font-medium text-mediumblue-100 text-center inline-block w-[99.6px] h-[24.8px]">
        Share Dream
      </div>
      <div className="absolute top-[59.8px] left-[1100.6px] leading-[21px] font-medium text-white text-center inline-block w-[99.6px] h-[24.8px]">
        Share Dream
      </div>
      <div className="absolute top-[46.9px] left-[1241.4px] shadow-[0px_8px_32px_rgba(67,_24,_209,_0.2),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-mediumblue-200 w-[146.5px] h-[49.7px]" />
      <div className="absolute top-[58.8px] left-[1268.9px] leading-[21px] font-medium text-white text-center inline-block w-[92.7px] h-[24.8px]">
        Mint as NFT
      </div>
      <div className="absolute top-[58.8px] left-[1268.9px] leading-[21px] font-medium text-white text-center inline-block w-[92.7px] h-[24.8px]">
        Mint as NFT
      </div>
      <div className="absolute top-[134.5px] left-[69px] shadow-[0px_4px_12px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-white border-aliceblue border-solid border-[1px] box-border w-[938.8px] h-[740.4px]" />
      <div className="absolute top-[173.5px] left-[106.8px] rounded-26843481xl bg-aliceblue w-[51.5px] h-[50.9px]" />
      <img
        className="absolute h-[2.07%] w-[1.2%] top-[18.38%] right-[90.2%] bottom-[79.55%] left-[8.6%] max-w-full overflow-hidden max-h-full"
        alt=""
        src="/vector4.svg"
      />
      <div className="absolute top-[177px] left-[176.6px] text-5xl leading-[36px] font-semibold text-gray-100 inline-block w-[298.8px] h-[42.6px]">
        Flying Over Mountains
      </div>
      <div className="absolute top-[252.7px] left-[106.8px] rounded-sm bg-ghostwhite w-[64.1px] h-[33.1px]" />
      <div className="absolute top-[257.5px] left-[120.5px] text-xs leading-[18px] text-mediumblue-100 inline-block w-[36.6px] h-[21.3px]">
        flying
      </div>
      <div className="absolute top-[252.7px] left-[178.9px] rounded-sm bg-ghostwhite w-[95px] h-[33.1px]" />
      <div className="absolute top-[257.5px] left-[192.7px] text-xs leading-[18px] text-mediumblue-100 inline-block w-[67.5px] h-[21.3px]">
        mountains
      </div>
      <div className="absolute top-[252.7px] left-[283.1px] rounded-sm bg-ghostwhite w-[82.4px] h-[33.1px]" />
      <div className="absolute top-[257.5px] left-[296.8px] text-xs leading-[18px] text-mediumblue-100 inline-block w-[55px] h-[21.3px]">
        freedom
      </div>
      <div className="absolute top-[252.7px] left-[374.7px] rounded-sm bg-ghostwhite w-[68.7px] h-[33.1px]" />
      <div className="absolute top-[257.5px] left-[388.4px] text-xs leading-[18px] text-mediumblue-100 inline-block w-[42.4px] h-[21.3px]">
        nature
      </div>
      <div className="absolute top-[314.2px] left-[106.8px] rounded-xl bg-ghostwhite w-[863.3px] h-[242.5px]" />
      <div className="absolute top-[342.6px] left-[134.3px] rounded-lg bg-midnightblue-300 w-[48.1px] h-[49.7px]" />
      <img
        className="absolute h-[1.39%] w-[0.79%] top-[35.2%] right-[88.61%] bottom-[63.42%] left-[10.6%] max-w-full overflow-hidden max-h-full"
        alt=""
        src="/vector5.svg"
      />
      <div className="absolute top-[354.5px] left-[196.1px] leading-[21px] inline-block w-[93.9px] h-[24.8px]">
        00:00 / 2:30
      </div>
      <img
        className="absolute h-[1.15%] w-[0.79%] top-[35.3%] right-[43.37%] bottom-[63.54%] left-[55.83%] max-w-full overflow-hidden max-h-full"
        alt=""
        src="/vector6.svg"
      />
      <div className="absolute top-[354.5px] left-[823.5px] leading-[21px] text-mediumblue-100 text-center inline-block w-[120.2px] h-[24.8px]">
        Add Timestamp
      </div>
      <div className="absolute top-[411.2px] left-[134.3px] rounded-sm bg-lavender-300 w-[808.3px] h-[4.7px]" />
      <div className="absolute top-[433.7px] left-[134.3px] leading-[21px] text-mediumblue-100 inline-block w-[32.1px] h-[24.8px]">
        0:15
      </div>
      <div className="absolute top-[433.7px] left-[178.9px] leading-[21px] inline-block w-[176.3px] h-[24.8px]">
        Initial takeoff sensation
      </div>
      <div className="absolute top-[468px] left-[134.3px] leading-[21px] text-mediumblue-100 inline-block w-[35.5px] h-[24.8px]">
        0:45
      </div>
      <div className="absolute top-[468px] left-[182.3px] leading-[21px] inline-block w-[193.5px] h-[24.8px]">
        Mountain peak encounter
      </div>
      <div className="absolute top-[502.3px] left-[134.3px] leading-[21px] text-mediumblue-100 inline-block w-[33.2px] h-[24.8px]">
        1:30
      </div>
      <div className="absolute top-[502.3px] left-[178.9px] leading-[21px] inline-block w-[186.6px] h-[24.8px]">
        Wind current description
      </div>
      <div className="absolute top-[594.6px] left-[106.8px] text-base leading-[24px] font-semibold text-gray-100 inline-block w-[164.9px] h-[28.4px]">
        Dream Description
      </div>
      <div className="absolute top-[643.1px] left-[106.8px] text-mini leading-[22.5px] text-darkslategray inline-block w-[855.2px] h-[106.5px]">
        Soaring through misty peaks at dawn, feeling weightless and free as I
        glided between ancient mountain ranges. The air was crisp and clear,
        carrying whispers of ancient stories through the clouds. The mountains
        stretched endlessly beneath me, their snow-capped peaks glowing in the
        early morning light. I could feel every subtle air current, every shift
        in the wind, as if the sky itself was teaching me how to fly.
      </div>
      <div className="absolute top-[786.2px] left-[106.8px] rounded-lg bg-midnightblue-300 border-mediumblue-100 border-solid border-[1px] box-border w-[139.7px] h-[49.7px]" />
      <div className="absolute top-[798px] left-[135.4px] leading-[21px] font-medium text-white text-center inline-block w-[84.7px] h-[24.8px]">
        Edit Dream
      </div>
      <div className="absolute top-[786.2px] left-[260.2px] rounded-lg border-orangered border-solid border-[1px] box-border w-[160.3px] h-[49.7px]" />
      <div className="absolute top-[798px] left-[288.8px] leading-[21px] font-medium text-orangered text-center inline-block w-[104.2px] h-[24.8px]">
        Delete Dream
      </div>
      <div className="absolute top-[135px] left-[1046px] shadow-[0px_4px_12px_rgba(0,_0,_0,_0.03),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] rounded-2xl bg-white border-aliceblue border-solid border-[1px] box-border w-[344px] h-[488px]" />
      <div className="absolute top-[163px] left-[1074.9px] leading-[21px] font-semibold inline-block w-[128.2px] h-[24.8px]">
        DREAM DETAILS
      </div>
      <div className="absolute top-[206.8px] left-[1074.9px] text-xs leading-[18px] inline-block w-[79px] h-[21.3px]">
        Dream Type
      </div>
      <div className="absolute top-[232.8px] left-[1074.9px] leading-[21px] text-gray-100 inline-block w-[124.8px] h-[24.8px]">
        Audio Recording
      </div>
      <div className="absolute top-[276.5px] left-[1074.9px] text-xs leading-[18px] inline-block w-[56.1px] h-[21.3px]">
        Duration
      </div>
      <div className="absolute top-[302.6px] left-[1074.9px] leading-[21px] text-gray-100 inline-block w-[34.3px] h-[24.8px]">
        2:30
      </div>
      <div className="absolute top-[346.3px] left-[1074.9px] text-xs leading-[18px] inline-block w-[37.8px] h-[21.3px]">
        Mood
      </div>
      <div className="absolute top-[372.4px] left-[1074.9px] leading-[21px] text-gray-100 inline-block w-[66.4px] h-[24.8px]">
        Peaceful
      </div>
      <div className="absolute top-[416.1px] left-[1074.9px] text-xs leading-[18px] inline-block w-[51.5px] h-[21.3px]">
        Lucidity
      </div>
      <div className="absolute top-[442.1px] left-[1074.9px] leading-[21px] text-gray-100 inline-block w-[81.3px] h-[24.8px]">
        Semi-lucid
      </div>
      <div className="absolute top-[496px] left-[1073px] leading-[21px] font-semibold inline-block w-[146.5px] h-[24.8px]">
        DREAM SUMMARY
      </div>
      <div className="absolute top-[534px] left-[1073px] leading-[21px] text-darkslategray inline-block w-[280.5px] h-[74.5px]">
        A vivid flying dream featuring mountain landscapes and sensations of
        freedom
      </div>
    </div>
  );
};

export default NFTPageForAudio;

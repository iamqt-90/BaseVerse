import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const HomePage: FunctionComponent = () => {
  const navigate = useNavigate();

  const onGroupContainerClick = useCallback(() => {
    navigate("/dreaming-page");
  }, [navigate]);

  const onHomeTextClick = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='rectangle']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onGalleryTextClick = useCallback(() => {
    navigate("/gallary-page");
  }, [navigate]);

  const onProfileTextClick = useCallback(() => {
    navigate("/user-dashboard");
  }, [navigate]);

  const onConnectWalletTextClick = useCallback(() => {
    navigate("/wallet-page");
  }, [navigate]);

  return (
    <div className="w-full relative h-[1024px] text-left text-lg text-white font-inter hover:bg-white hover:animate-[1s_ease_0s_infinite_normal_none_scale-up] hover:opacity-[1]">
      <div className="absolute top-[0px] left-[0px] [background:linear-gradient(180deg,_#00004a_47.12%,_#000)] w-[1440px] h-[1024px]" />
      <img
        className="absolute top-[102px] left-[0px] w-[1440px] h-[542px] object-cover"
        alt=""
        src="/rectangle@2x.png"
      />
      <b className="absolute top-[228.6px] left-[167.7px] text-51xl leading-[96px] inline-block font-archivo text-center w-[1141.1px] h-[86.7px]">{`Record your dreams & mint them!`}</b>
      <div className="absolute top-[336.7px] left-[284.2px] text-5xl leading-[36px] text-center inline-block w-[872.8px] h-[65px]">
        Transform your story into digital collectibles and explore a gallery of
        imagination.
      </div>
      <div
        className="absolute top-[447px] left-[572px] w-[281px] h-[58px] cursor-pointer text-center text-xl"
        onClick={onGroupContainerClick}
      >
        <div className="absolute top-[0px] left-[0px] rounded-lg bg-midnightblue-400 w-[281px] h-[58px]" />
        <div className="absolute top-[calc(50%_-_15px)] left-[calc(50%_-_71.5px)] leading-[27px] font-semibold inline-block w-[149.4px] h-[24.4px]">
          Start Dreaming
        </div>
      </div>
      <img
        className="absolute top-[686px] left-[22px] rounded-24xl w-[444px] h-[266px] object-cover"
        alt=""
        src="/image2@2x.png"
      />
      <img
        className="absolute top-[686px] left-[977px] rounded-24xl w-[444px] h-[266px] object-cover"
        alt=""
        src="/image2@2x.png"
      />
      <img
        className="absolute top-[686px] left-[497px] rounded-24xl w-[454px] h-[266px] object-cover"
        alt=""
        src="/image3@2x.png"
      />
      <div
        className="absolute top-[0px] left-[0px] shadow-[0px_2px_8px_rgba(0,_0,_0,_0.05),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0),_0px_0px_0px_rgba(0,_0,_0,_0)] [background:radial-gradient(50%_50%_at_50%_50%,_#0e0037_42.31%,_#08001d)] w-[1440px] h-[102px]"
        data-scroll-to="rectangle"
      />
      <b className="absolute top-[24px] left-[27px] text-17xl leading-[48px] inline-block font-archivo w-[225px] h-11 [text-shadow:1px_0_0_rgba(0,_0,_0,_0),_0_1px_0_rgba(0,_0,_0,_0),_-1px_0_0_rgba(0,_0,_0,_0),_0_-1px_0_rgba(0,_0,_0,_0)]">
        DreamScape
      </b>
      <b
        className="absolute top-[41px] left-[323px] leading-[24px] inline-block w-[52.1px] h-[21.7px] cursor-pointer"
        onClick={onHomeTextClick}
      >
        Home
      </b>
      <div
        className="absolute top-[40.3px] left-[436.4px] leading-[24px] inline-block w-[60px] h-[21.7px] cursor-pointer"
        onClick={onGalleryTextClick}
      >
        Gallery
      </div>
      <div
        className="absolute top-[41.3px] left-[558.6px] leading-[24px] inline-block w-[55.5px] h-[21.7px] cursor-pointer"
        onClick={onProfileTextClick}
      >
        Profile
      </div>
      <div className="absolute top-[42.3px] left-[1044.6px] leading-[24px] inline-block w-[94px] h-[21.7px]">
        Contact us
      </div>
      <div className="absolute top-[30.4px] left-[1193.8px] w-[217.8px] h-[43.3px]">
        <div className="absolute top-[0px] left-[0px] w-[217.8px] h-[43.3px]">
          <div className="absolute top-[0px] left-[0px] rounded-lg bg-midnightblue-200 w-[217.8px] h-[43.3px]" />
        </div>
      </div>
      <div
        className="absolute top-[40px] left-[1242px] text-base leading-[24px] font-semibold text-center inline-block w-[119px] h-[22px] cursor-pointer"
        onClick={onConnectWalletTextClick}
      >
        <p className="m-0">Connect Wallet</p>
      </div>
    </div>
  );
};

export default HomePage;
